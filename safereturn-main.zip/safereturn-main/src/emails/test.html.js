export const test=`<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        h1 {
            color: #ff69b4; 
            text-align: center;
            font-size: 60px;
            font-family: 'Comic Sans MS', cursive, sans-serif;
            text-shadow: 2px 2px 5px #333; 
        }
    </style>
</head>

<body>
        <h1>My cat is cuter than yours</h1>
</body>

</html>`